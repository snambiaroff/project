from django.apps import AppConfig


class CodingToolsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'coding_tools'
